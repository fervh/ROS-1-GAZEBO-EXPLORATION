#!/usr/bin/env python

"""import rospy
from geometry_msgs.msg import Twist

def exploration_node():
    rospy.init_node('exploration_node', anonymous=True)
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(10)  # 10hz

    while not rospy.is_shutdown():
        twist = Twist()
        twist.angular.z = 1.0  # Velocidad de giro
        pub.publish(twist)
        rate.sleep()

if __name__ == '__main__':
    try:
        exploration_node()
    except rospy.ROSInterruptException:
        pass
"""

# Nodo de exploracion basado en el topic /map y los bordes de celdas libres y ocupadas topics de tipo Pointcloud /borde_libre y /borde_ocupado, usando PID para controlar el robot y RRT para la plane. Para saber la orientacion ve hacia donde mayor densidad de bordes libres hay sin chocarte, usando RRT.
#!/usr/bin/env python

import rospy
from sensor_msgs.msg import PointCloud
from geometry_msgs.msg import PoseStamped, Point
from tf import TransformListener
import numpy as np

class EdgeDirectionPublisher:
    def __init__(self):
        rospy.init_node('edge_direction_publisher', anonymous=True)
        self.listener = TransformListener()
        self.edge_subscriber = rospy.Subscriber('/borde_libre', PointCloud, self.edge_callback)
        self.pose_publisher = rospy.Publisher('/edge_direction', PoseStamped, queue_size=10)

    def edge_callback(self, data):
        if len(data.points) == 0:
            rospy.logwarn("No hay puntos en el borde libre")
            return

        try:
            # Obtenemos la transformación entre 'map' y 'base_footprint'
            self.listener.waitForTransform('map', 'base_footprint', rospy.Time(), rospy.Duration(1.0))
            (trans, rot) = self.listener.lookupTransform('map', 'base_footprint', rospy.Time(0))
        except:
            rospy.logwarn("No se pudo obtener la transformación entre 'map' y 'base_footprint'")
            return

        # Convertimos los puntos del borde libre a un array numpy para facilitar el procesamiento
        points = np.array([[p.x, p.y, p.z] for p in data.points])

        # Calculamos el centroide de los puntos del borde libre
        centroid = np.mean(points, axis=0)

        # Calculamos el vector hacia el punto con mayor densidad de puntos
        direction = np.argmax(np.sum((points - centroid) ** 2, axis=1))
        max_density_point = points[direction]

        # Calculamos el ángulo entre la orientación de 'base_footprint' y el vector que apunta al punto de mayor densidad
        angle = np.arctan2(max_density_point[1] - trans[1], max_density_point[0] - trans[0]) - np.arctan2(rot[1], rot[0])

        # Creamos el mensaje de tipo PoseStamped
        pose_msg = PoseStamped()
        pose_msg.header.stamp = rospy.Time.now()
        pose_msg.header.frame_id = 'base_footprint'  # La posición del robot se considera como el marco de referencia
        pose_msg.pose.position = Point(0, 0, 0)
        pose_msg.pose.orientation.w = np.cos(angle / 2.0)
        pose_msg.pose.orientation.z = np.sin(angle / 2.0)

        # Publicamos el mensaje de tipo PoseStamped
        self.pose_publisher.publish(pose_msg)

if __name__ == '__main__':
    try:
        edge_direction_publisher = EdgeDirectionPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

